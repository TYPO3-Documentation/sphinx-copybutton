===========================
A nested page for reference
===========================

To make sure that the images / svg still works!

.. code-block:: python

   e = mc^2
